var KYCContract = artifacts.require("KYCContract");

module.exports = function(deployer) {
  // deployment steps
  rpcUrl: 'http://localhost:30304',
  port: 7545
  deployer.deploy(KYCContract);
};
